# Dabaran Cold Outreach Report — with GitHub auto-save

Ye woh hi offline dashboard hai (edit karein, save karein, save history dekhein — sab kuch offline localStorage mein kaam karta hai), lekin ismein ek extra cheez add ki gayi hai: **"Save changes" click karne par, agar aap setup kar dein, to us waqt ki dashboard snapshot automatically aapke GitHub repo mein ek real file ke taur par commit ho jati hai.**

## Files

- `index.html`, `styles.css`, `script.js` — dashboard (offline mein bhi poora kaam karta hai, jaisa pehle wala version)
- `worker/worker.js` — ek chhota sa Cloudflare Worker jo GitHub token ko mehfooz rakhta hai aur file commit karta hai
- `worker/SETUP.md` — **step-by-step guide** GitHub + Cloudflare setup karne ke liye

## Zaroori: GitHub push by default OFF hai

`script.js` ke shuru mein `GITHUB_SAVE_CONFIG.enabled` `false` par set hai. Jab tak aap `worker/SETUP.md` ke steps poore nahi karte, dashboard bilkul pehle jaisa hi kaam karega (localStorage save, save history, naya tab) — GitHub wala hissa chup chap kuch nahi karega, koi error bhi nahi degi.

Setup poora karne ke baad `enabled: true` kar dein aur `workerUrl` + `dashboardKey` bhar dein — phir har "Save changes" click GitHub mein bhi ek file bana dega, aur save button ke pass ek chhota status dikhega ("Pushing to GitHub…" → "Pushed to GitHub ✓").

Poori setup guide ke liye `worker/SETUP.md` kholein.
