(function () {
  // ====== GitHub auto-save configuration ======
  // Fill these in after you deploy the Cloudflare Worker -- see SETUP.md
  // in the "worker" folder for the full step-by-step guide. Leave
  // `enabled: false` until both values below are filled in, or every
  // "Save changes" click will fail trying to reach a worker that isn't
  // configured yet.
  var GITHUB_SAVE_CONFIG = {
    enabled: false,        // set to true once workerUrl + dashboardKey are filled in
    workerUrl: "",         // e.g. "https://dabaran-save-worker.YOURSUBDOMAIN.workers.dev"
    dashboardKey: ""       // must exactly match DASHBOARD_SHARED_KEY set on the Worker
  };
  // ================================================

  var STORAGE_KEY = "dabaran-cold-outreach-report:state";
  var DEFAULT_STATE = {"campaigns": [{"name": "$100 LP | EST | Home Services | 1-10 | Valid", "segment": "ET home-services owners, 1\u201310 employees, verified-valid list", "window": "9:00 AM\u20131:00 PM ET \u00b7 Jul 21", "sent": 3291, "opens": 1464, "replies": 8, "dnc": 0, "interested": 0, "opportunities": 0, "meetings": 0, "status": "Complete", "completed": "Aug 13, 2026", "openRate": 44.48495897903373, "replyRate": 0.24308720753570343}, {"name": "AI Search Growth - US Multi Industry | 1-10", "segment": "Multi-industry owners, 1\u201310 employees, all US time zones", "window": "1:00\u20135:00 PM ET \u00b7 Jul 23", "sent": 1994, "opens": 1314, "replies": 9, "dnc": 1, "interested": 0, "opportunities": 0, "meetings": 0, "status": "Complete", "completed": "Aug 6, 2026", "openRate": 65.89769307923771, "replyRate": 0.4513540621865597}, {"name": "US Dentist Clinics | Owners | 1\u201320 | ET CT", "segment": "Dental practice/clinic owners, 1\u201320 employees", "window": "1:00\u20135:00 PM ET \u00b7 Jul 24", "sent": 1415, "opens": 1024, "replies": 3, "dnc": 1, "interested": 0, "opportunities": 0, "meetings": 0, "status": "Complete", "completed": "Aug 18, 2026", "openRate": 72.36749116607774, "replyRate": 0.21201413427561835}, {"name": "LP+ SEO | (CT) Home Services | 1-10 | Catch-All", "segment": "CT home-services owners, 1\u201310 employees, catch-all list", "window": "9:30 AM\u20131:00 PM CT \u00b7 Jul 21", "sent": 1601, "opens": 441, "replies": 8, "dnc": 0, "interested": 1, "opportunities": 1, "meetings": 0, "status": "Complete", "completed": "Aug 20, 2026", "openRate": 27.545284197376642, "replyRate": 0.49968769519050593}, {"name": "LP+ SEO | (CT) Home Services | 1-10 | Valid", "segment": "CT home-services owners, 1\u201310 employees, verified-valid list", "window": "9:30 AM\u20131:00 PM CT \u00b7 Jul 21", "sent": 2868, "opens": 1300, "replies": 10, "dnc": 1, "interested": 0, "opportunities": 0, "meetings": 0, "status": "Complete", "completed": "Aug 20, 2026", "openRate": 45.32775453277546, "replyRate": 0.3486750348675035}, {"name": "$100 LP | EST | Home Services | 1-10 | Catch-All", "segment": "ET home-services owners, 1\u201310 employees, catch-all list", "window": "9:00 AM\u20131:00 PM ET \u00b7 Jul 21", "sent": 1355, "opens": 737, "replies": 8, "dnc": 2, "interested": 0, "opportunities": 0, "meetings": 0, "status": "Complete", "completed": "Aug 22, 2026", "openRate": 54.39114391143911, "replyRate": 0.5904059040590406}], "overrides": {"sent": 22222, "openRate": 55}, "title": "Dabaran Cold Outreach Report", "subtitle": "Seven prospecting sends across home services, dental, and multi-industry lists \u2014 July 21\u201324, 2026 launch window.", "history": [{"savedAt": "2026-09-11T20:48:01.319Z", "campaigns": [{"name": "$100 LP | EST | Home Services | 1-10 | Valid", "segment": "ET home-services owners, 1\u201310 employees, verified-valid list", "window": "9:00 AM\u20131:00 PM ET \u00b7 Jul 21", "sent": 3291, "opens": 1464, "replies": 8, "dnc": 0, "interested": 0, "opportunities": 0, "meetings": 0, "status": "Complete", "completed": "Aug 13, 2026", "openRate": 44.48495897903373, "replyRate": 0.24308720753570343}, {"name": "AI Search Growth - US Multi Industry | 1-10", "segment": "Multi-industry owners, 1\u201310 employees, all US time zones", "window": "1:00\u20135:00 PM ET \u00b7 Jul 23", "sent": 1994, "opens": 1314, "replies": 9, "dnc": 1, "interested": 0, "opportunities": 0, "meetings": 0, "status": "Complete", "completed": "Aug 6, 2026", "openRate": 65.89769307923771, "replyRate": 0.4513540621865597}, {"name": "US Dentist Clinics | Owners | 1\u201320 | ET CT", "segment": "Dental practice/clinic owners, 1\u201320 employees", "window": "1:00\u20135:00 PM ET \u00b7 Jul 24", "sent": 1415, "opens": 1024, "replies": 3, "dnc": 1, "interested": 0, "opportunities": 0, "meetings": 0, "status": "Complete", "completed": "Aug 18, 2026", "openRate": 72.36749116607774, "replyRate": 0.21201413427561835}, {"name": "LP+ SEO | (CT) Home Services | 1-10 | Catch-All", "segment": "CT home-services owners, 1\u201310 employees, catch-all list", "window": "9:30 AM\u20131:00 PM CT \u00b7 Jul 21", "sent": 1601, "opens": 441, "replies": 8, "dnc": 0, "interested": 1, "opportunities": 1, "meetings": 0, "status": "Complete", "completed": "Aug 20, 2026", "openRate": 27.545284197376642, "replyRate": 0.49968769519050593}, {"name": "LP+ SEO | (CT) Home Services | 1-10 | Valid", "segment": "CT home-services owners, 1\u201310 employees, verified-valid list", "window": "9:30 AM\u20131:00 PM CT \u00b7 Jul 21", "sent": 2868, "opens": 1300, "replies": 10, "dnc": 1, "interested": 0, "opportunities": 0, "meetings": 0, "status": "Complete", "completed": "Aug 20, 2026", "openRate": 45.32775453277546, "replyRate": 0.3486750348675035}, {"name": "$100 LP | EST | Home Services | 1-10 | Catch-All", "segment": "ET home-services owners, 1\u201310 employees, catch-all list", "window": "9:00 AM\u20131:00 PM ET \u00b7 Jul 21", "sent": 1355, "opens": 737, "replies": 8, "dnc": 2, "interested": 0, "opportunities": 0, "meetings": 0, "status": "Complete", "completed": "Aug 22, 2026", "openRate": 54.39114391143911, "replyRate": 0.5904059040590406}], "overrides": {"sent": 22222, "openRate": 55}, "title": "Dabaran Cold Outreach Report", "subtitle": "Seven prospecting sends across home services, dental, and multi-industry lists \u2014 July 21\u201324, 2026 launch window."}, {"savedAt": "2026-09-11T20:52:21.455Z", "campaigns": [{"name": "$100 LP | EST | Home Services | 1-10 | Valid", "segment": "ET home-services owners, 1\u201310 employees, verified-valid list", "window": "9:00 AM\u20131:00 PM ET \u00b7 Jul 21", "sent": 3291, "opens": 1464, "replies": 8, "dnc": 0, "interested": 0, "opportunities": 0, "meetings": 0, "status": "Complete", "completed": "Aug 13, 2026", "openRate": 44.48495897903373, "replyRate": 0.24308720753570343}, {"name": "AI Search Growth - US Multi Industry | 1-10", "segment": "Multi-industry owners, 1\u201310 employees, all US time zones", "window": "1:00\u20135:00 PM ET \u00b7 Jul 23", "sent": 1994, "opens": 1314, "replies": 9, "dnc": 1, "interested": 0, "opportunities": 0, "meetings": 0, "status": "Complete", "completed": "Aug 6, 2026", "openRate": 65.89769307923771, "replyRate": 0.4513540621865597}, {"name": "US Dentist Clinics | Owners | 1\u201320 | ET CT", "segment": "Dental practice/clinic owners, 1\u201320 employees", "window": "1:00\u20135:00 PM ET \u00b7 Jul 24", "sent": 1415, "opens": 1024, "replies": 3, "dnc": 1, "interested": 0, "opportunities": 0, "meetings": 0, "status": "Complete", "completed": "Aug 18, 2026", "openRate": 72.36749116607774, "replyRate": 0.21201413427561835}, {"name": "LP+ SEO | (CT) Home Services | 1-10 | Catch-All", "segment": "CT home-services owners, 1\u201310 employees, catch-all list", "window": "9:30 AM\u20131:00 PM CT \u00b7 Jul 21", "sent": 1601, "opens": 441, "replies": 8, "dnc": 0, "interested": 1, "opportunities": 1, "meetings": 0, "status": "Complete", "completed": "Aug 20, 2026", "openRate": 27.545284197376642, "replyRate": 0.49968769519050593}, {"name": "LP+ SEO | (CT) Home Services | 1-10 | Valid", "segment": "CT home-services owners, 1\u201310 employees, verified-valid list", "window": "9:30 AM\u20131:00 PM CT \u00b7 Jul 21", "sent": 2868, "opens": 1300, "replies": 10, "dnc": 1, "interested": 0, "opportunities": 0, "meetings": 0, "status": "Complete", "completed": "Aug 20, 2026", "openRate": 45.32775453277546, "replyRate": 0.3486750348675035}, {"name": "$100 LP | EST | Home Services | 1-10 | Catch-All", "segment": "ET home-services owners, 1\u201310 employees, catch-all list", "window": "9:00 AM\u20131:00 PM ET \u00b7 Jul 21", "sent": 1355, "opens": 737, "replies": 8, "dnc": 2, "interested": 0, "opportunities": 0, "meetings": 0, "status": "Complete", "completed": "Aug 22, 2026", "openRate": 54.39114391143911, "replyRate": 0.5904059040590406}], "overrides": {"sent": 22222, "openRate": 55}, "title": "Dabaran Cold Outreach Report", "subtitle": "Seven prospecting sends across home services, dental, and multi-industry lists \u2014 July 21\u201324, 2026 launch window."}, {"savedAt": "2026-09-11T21:02:04.203Z", "campaigns": [{"name": "$100 LP | EST | Home Services | 1-10 | Valid", "segment": "ET home-services owners, 1\u201310 employees, verified-valid list", "window": "9:00 AM\u20131:00 PM ET \u00b7 Jul 21", "sent": 3291, "opens": 1464, "replies": 8, "dnc": 0, "interested": 0, "opportunities": 0, "meetings": 0, "status": "Complete", "completed": "Aug 13, 2026", "openRate": 44.48495897903373, "replyRate": 0.24308720753570343}, {"name": "AI Search Growth - US Multi Industry | 1-10", "segment": "Multi-industry owners, 1\u201310 employees, all US time zones", "window": "1:00\u20135:00 PM ET \u00b7 Jul 23", "sent": 1994, "opens": 1314, "replies": 9, "dnc": 1, "interested": 0, "opportunities": 0, "meetings": 0, "status": "Complete", "completed": "Aug 6, 2026", "openRate": 65.89769307923771, "replyRate": 0.4513540621865597}, {"name": "US Dentist Clinics | Owners | 1\u201320 | ET CT", "segment": "Dental practice/clinic owners, 1\u201320 employees", "window": "1:00\u20135:00 PM ET \u00b7 Jul 24", "sent": 1415, "opens": 1024, "replies": 3, "dnc": 1, "interested": 0, "opportunities": 0, "meetings": 0, "status": "Complete", "completed": "Aug 18, 2026", "openRate": 72.36749116607774, "replyRate": 0.21201413427561835}, {"name": "LP+ SEO | (CT) Home Services | 1-10 | Catch-All", "segment": "CT home-services owners, 1\u201310 employees, catch-all list", "window": "9:30 AM\u20131:00 PM CT \u00b7 Jul 21", "sent": 1601, "opens": 441, "replies": 8, "dnc": 0, "interested": 1, "opportunities": 1, "meetings": 0, "status": "Complete", "completed": "Aug 20, 2026", "openRate": 27.545284197376642, "replyRate": 0.49968769519050593}, {"name": "LP+ SEO | (CT) Home Services | 1-10 | Valid", "segment": "CT home-services owners, 1\u201310 employees, verified-valid list", "window": "9:30 AM\u20131:00 PM CT \u00b7 Jul 21", "sent": 2868, "opens": 1300, "replies": 10, "dnc": 1, "interested": 0, "opportunities": 0, "meetings": 0, "status": "Complete", "completed": "Aug 20, 2026", "openRate": 45.32775453277546, "replyRate": 0.3486750348675035}, {"name": "$100 LP | EST | Home Services | 1-10 | Catch-All", "segment": "ET home-services owners, 1\u201310 employees, catch-all list", "window": "9:00 AM\u20131:00 PM ET \u00b7 Jul 21", "sent": 1355, "opens": 737, "replies": 8, "dnc": 2, "interested": 0, "opportunities": 0, "meetings": 0, "status": "Complete", "completed": "Aug 22, 2026", "openRate": 54.39114391143911, "replyRate": 0.5904059040590406}], "overrides": {"sent": 22222, "openRate": 55}, "title": "Dabaran Cold Outreach Report", "subtitle": "Seven prospecting sends across home services, dental, and multi-industry lists \u2014 July 21\u201324, 2026 launch window."}], "lastSaved": "2026-09-11T21:02:04.203Z"};
  var STATE = (function () {
    try {
      var raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) { return JSON.parse(raw); }
    } catch (e) { /* localStorage unavailable (e.g. file:// in some browsers) - fall back below */ }
    return DEFAULT_STATE;
  })();

  var campaigns = STATE.campaigns;
  STATE.overrides = STATE.overrides || {};
  STATE.history = Array.isArray(STATE.history) ? STATE.history : [];
  var dirty = false;
  // A "?report=1" (or "#report") link opens this same saved document in a locked, no-editing
  // view — since it's the same page and the same STATE, whatever gets saved here shows there
  // too, automatically, with no separate publish step. Hash is checked too because some hosts
  // don't forward query strings through to the served page, but a URL fragment always survives
  // (it's never sent to the server, so nothing server-side can strip it).
  var isReportMode = /(^|[?&])report=1(&|$)/.test(window.location.search) || /report/i.test(window.location.hash);

  function fmt(n) { return (Math.round(n * 100) / 100).toLocaleString("en-US"); }
  function pct(n, d) { d = d === undefined ? 2 : d; if (!isFinite(n)) n = 0; return n.toFixed(d) + "%"; }
  function num(v) { var n = parseFloat(v); return isFinite(n) && n >= 0 ? n : 0; }

  function formatByKind(kind, n) {
    if (kind === "pct1") return pct(n, 1);
    if (kind === "pct2") return pct(n, 2);
    return fmt(n);
  }
  function parseByKind(kind, text) {
    var cleaned = String(text).replace(/[^0-9.]/g, "");
    var n = parseFloat(cleaned);
    if (!isFinite(n) || n < 0) n = 0;
    if (kind !== "pct1" && kind !== "pct2") n = Math.round(n);
    return n;
  }

  function recalcRates() {
    campaigns.forEach(function (c) {
      c.sent = Math.round(num(c.sent));
      c.opens = Math.round(num(c.opens));
      c.replies = Math.round(num(c.replies));
      c.dnc = Math.round(num(c.dnc));
      c.interested = Math.round(num(c.interested));
      c.opportunities = Math.round(num(c.opportunities));
      c.meetings = Math.round(num(c.meetings));
      c.openRate = c.sent > 0 ? (c.opens / c.sent * 100) : 0;
      c.replyRate = c.sent > 0 ? (c.replies / c.sent * 100) : 0;
    });
  }

  function totals() {
    var t = campaigns.reduce(function (a, c) {
      a.sent += c.sent; a.opens += c.opens; a.dnc += c.dnc; a.replies += c.replies;
      a.interested += c.interested; a.opportunities += c.opportunities;
      return a;
    }, { sent: 0, opens: 0, dnc: 0, replies: 0, interested: 0, opportunities: 0 });
    t.openRate = t.sent > 0 ? (t.opens / t.sent * 100) : 0;
    t.replyRate = t.sent > 0 ? (t.replies / t.sent * 100) : 0;
    return t;
  }

  function pillClassFor(status) {
    if (status === "Complete") return "good";
    if (status === "Continue for Sending") return "warn";
    return "neutral";
  }

  var tip = document.getElementById("tip");
  function showTip(evt, html) {
    tip.innerHTML = html;
    tip.style.left = evt.clientX + "px";
    tip.style.top = evt.clientY + "px";
    tip.classList.add("show");
  }
  function hideTip() { tip.classList.remove("show"); }

  // ---------- Save history (a running log — one entry per successful save, each openable) ----------
  function formatWhen(iso) {
    return iso
      ? new Date(iso).toLocaleString("en-US", { month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit", second: "2-digit" })
      : "Unknown time";
  }

  function renderSaveHistory() {
    var list = document.getElementById("saveHistoryList");
    var empty = document.getElementById("saveHistoryEmpty");
    var history = Array.isArray(STATE.history) ? STATE.history : [];
    list.innerHTML = "";
    if (!history.length) {
      empty.style.display = "";
      return;
    }
    empty.style.display = "none";
    history.slice().reverse().forEach(function (entry, i) {
      var saveNumber = history.length - i;
      var li = document.createElement("li");
      li.className = "clickable";
      li.tabIndex = 0;
      li.dataset.historyIndex = String(history.length - 1 - i);
      li.innerHTML = "<span>Save #" + saveNumber + "</span>" +
        "<span class=\"row-right\"><span class=\"save-view-hint\">Open \u2197</span><span class=\"when\">" + formatWhen(entry && entry.savedAt) + "</span>" +
        "<button type=\"button\" class=\"history-open-btn\" data-history-index=\"" + (history.length - 1 - i) + "\" title=\"Open this saved version in a new tab\">\u21d7</button>" +
        "<button type=\"button\" class=\"history-del-btn\" data-history-index=\"" + (history.length - 1 - i) + "\" title=\"Delete this saved version\">&times;</button></span>";
      list.appendChild(li);
    });
  }

  function renderHistorySnapshot(entry) {
    var body = document.getElementById("historyModalBody");
    if (!entry || !Array.isArray(entry.campaigns)) {
      body.innerHTML = "<p class=\"no-snapshot\">This save was recorded before version snapshots were turned on, so there's no saved dashboard to show for it \u2014 only the save time. Every save from now on keeps the full dashboard, so it can always be reopened later.</p>";
      return;
    }
    var sections = buildSnapshotSectionsHtml(entry);
    body.innerHTML = sections.kpiHtml + sections.panelsHtml + sections.tableHtml;
  }

  function buildSnapshotSectionsHtml(entry) {
    var snapCampaigns = entry.campaigns;
    var snapOverrides = entry.overrides || {};

    var t = snapCampaigns.reduce(function (a, c) {
      a.sent += num(c.sent); a.opens += num(c.opens); a.replies += num(c.replies); a.dnc += num(c.dnc);
      a.interested += num(c.interested); a.opportunities += num(c.opportunities);
      return a;
    }, { sent: 0, opens: 0, replies: 0, dnc: 0, interested: 0, opportunities: 0 });
    var meetings = snapCampaigns.reduce(function (a, c) { return a + (c.meetings || 0); }, 0);
    var openRateTotal = t.sent > 0 ? (t.opens / t.sent * 100) : 0;
    var replyRateTotal = t.sent > 0 ? (t.replies / t.sent * 100) : 0;

    // ---- Program totals (same KPI tiles as the live dashboard, honoring any manual overrides) ----
    var kpiDefs = [
      { label: "Contacts sent", val: fmt(snapOverrides.sent !== undefined ? snapOverrides.sent : t.sent), unit: "across " + snapCampaigns.length + " sends" },
      { label: "Open rate", val: pct(snapOverrides.openRate !== undefined ? snapOverrides.openRate : openRateTotal, 1), unit: fmt(t.opens) + " opened" },
      { label: "Reply rate", val: pct(snapOverrides.replyRate !== undefined ? snapOverrides.replyRate : replyRateTotal, 2), unit: fmt(t.replies) + " replies" },
      { label: "Interested replies", val: fmt(snapOverrides.interested !== undefined ? snapOverrides.interested : t.interested), unit: "of " + fmt(t.replies) + " replies" },
      { label: "Opportunities created", val: fmt(snapOverrides.opportunities !== undefined ? snapOverrides.opportunities : t.opportunities), unit: t.opportunities + " campaign" + (t.opportunities === 1 ? "" : "s") },
      { label: "Meetings booked", val: fmt(snapOverrides.meetings !== undefined ? snapOverrides.meetings : meetings), unit: meetings > 0 ? "booked to date" : "none yet this cycle" }
    ];
    var kpiHtml = '<p class="eyebrow">Program totals</p><div class="kpi-grid">' + kpiDefs.map(function (k) {
      return '<div class="kpi"><div class="label">' + k.label + '</div><div class="value-row"><span class="value" style="cursor:default">' + k.val + '</span></div><div class="caption">' + k.unit + '</div></div>';
    }).join("") + '</div>';

    // ---- Open rate by campaign (same bar chart as the live dashboard) ----
    var sorted = snapCampaigns.map(function (c) {
      var sent = num(c.sent), opens = num(c.opens);
      return { name: c.name, sent: sent, opens: opens, openRate: sent > 0 ? (opens / sent * 100) : 0 };
    }).sort(function (a, b) { return b.openRate - a.openRate; });
    var maxRate = Math.max.apply(null, sorted.map(function (c) { return c.openRate; })) || 1;
    var barHtml = sorted.map(function (c) {
      var widthPct = (c.openRate / maxRate) * 100;
      return '<div class="bar-row"><div class="name" title="' + escAttr(c.name) + '">' + (c.name || "Untitled") + '</div>' +
        '<div class="bar-track"><div class="bar-fill" style="width:' + widthPct.toFixed(1) + '%"></div></div>' +
        '<div class="pct">' + pct(c.openRate, 1) + '</div></div>';
    }).join("");

    // ---- Funnel (same 5-stage funnel as the live dashboard) ----
    var stages = [
      { stage: "Sent", value: t.sent, color: "var(--seq-1)" },
      { stage: "Opened", value: t.opens, color: "var(--seq-2)" },
      { stage: "Replied", value: t.replies, color: "var(--seq-3)" },
      { stage: "Interested", value: t.interested, color: "var(--seq-4)" },
      { stage: "Opportunity", value: t.opportunities, color: "var(--seq-5)" }
    ];
    var sqrtMax = Math.sqrt(stages[0].value) || 1;
    var funnelHtml = stages.map(function (s, i) {
      var w = Math.max((Math.sqrt(s.value) / sqrtMax) * 100, 3);
      var pctOfSent = t.sent > 0 ? (s.value / t.sent * 100) : 0;
      var pctLabel = pctOfSent >= 1 ? pctOfSent.toFixed(1) + "%" : pctOfSent.toFixed(3) + "%";
      var dropHtml = "";
      if (i > 0) {
        var prev = stages[i - 1];
        var convFromPrev = prev.value > 0 ? (s.value / prev.value * 100) : 0;
        var dropText = prev.stage === "Sent" ? (pctLabel + " of total sent") : (convFromPrev.toFixed(convFromPrev < 1 ? 2 : 1) + "% of " + prev.stage.toLowerCase() + " \u00b7 " + pctLabel + " of total sent");
        dropHtml = '<div class="funnel-drop">' + dropText + '</div>';
      }
      return '<div class="funnel-row"><div class="stage">' + s.stage + '</div><div class="funnel-track"><div class="funnel-fill" style="width:' + w.toFixed(1) + '%;background:' + s.color + '"></div></div><div class="count">' + fmt(s.value) + '</div></div>' + dropHtml;
    }).join("");

    var panelsHtml = '<div class="panels">' +
      '<div class="panel"><h2>Open rate by campaign</h2><p class="panel-sub">Opens \u00f7 total sent, ranked high to low</p>' + barHtml + '</div>' +
      '<div class="panel"><h2>Where the funnel narrows</h2><p class="panel-sub">All campaigns combined, sent \u2192 opportunity</p><div class="funnel">' + funnelHtml + '</div></div>' +
      '</div>';

    // ---- Full campaign table (every column, read-only) ----
    var rowsHtml = snapCampaigns.map(function (c) {
      var sent = num(c.sent), opens = num(c.opens), replies = num(c.replies);
      var oRate = sent > 0 ? (opens / sent * 100) : 0;
      var rRate = sent > 0 ? (replies / sent * 100) : 0;
      return '<tr>' +
        '<td><span style="font-weight:600">' + escAttr(c.name || "Untitled") + '</span>' + (c.segment ? '<span style="display:block;color:var(--ink-muted);font-size:11px">' + escAttr(c.segment) + '</span>' : '') + '</td>' +
        '<td>' + escAttr(c.window || "") + '</td>' +
        '<td class="num">' + fmt(sent) + '</td>' +
        '<td class="num">' + fmt(opens) + ' <span style="color:var(--ink-muted)">(' + pct(oRate, 1) + ')</span></td>' +
        '<td class="num">' + fmt(replies) + ' <span style="color:var(--ink-muted)">(' + pct(rRate, 2) + ')</span></td>' +
        '<td class="num">' + fmt(num(c.dnc)) + '</td>' +
        '<td class="num">' + fmt(num(c.interested)) + '</td>' +
        '<td class="num">' + fmt(num(c.opportunities)) + '</td>' +
        '<td class="num">' + fmt(num(c.meetings || 0)) + '</td>' +
        '<td><span class="pill ' + pillClassFor(c.status) + '"><span class="dot"></span>' + escAttr(c.status || "") + '</span></td>' +
        '<td>' + escAttr(c.completed || "") + '</td>' +
        '</tr>';
    }).join("");

    var tableHtml = '<p class="eyebrow">Campaign detail</p><div class="table-panel"><div class="table-scroll"><table><thead><tr>' +
      '<th>Campaign</th><th>Send window</th><th class="num">Sent</th><th class="num">Opened</th><th class="num">Replied</th><th class="num">DNC</th><th class="num">Interested</th><th class="num">Opps</th><th class="num">Meetings</th><th>Status</th><th>Completed</th>' +
      '</tr></thead><tbody>' + rowsHtml + '</tbody></table></div></div>';

    return { kpiHtml: kpiHtml, panelsHtml: panelsHtml, tableHtml: tableHtml };
  }

  function buildHistoryStandaloneDoc(entry, index) {
    var titleText = (typeof entry.title === "string" && entry.title) ? entry.title : STATE.title;
    var subtitleText = (typeof entry.subtitle === "string") ? entry.subtitle : STATE.subtitle;
    var styleTag = document.querySelector("style");
    var css = styleTag ? styleTag.outerHTML : "";
    var fontLinks = '<link rel="preconnect" href="https://fonts.googleapis.com">' +
      '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' +
      '<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600&family=IBM+Plex+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600&display=swap" rel="stylesheet">';
    var bodyInner;
    if (!entry || !Array.isArray(entry.campaigns)) {
      bodyInner = '<div class="wrap"><div class="masthead"><div><h1>' + escAttr(titleText) + '</h1><p class="sub">' + escAttr(subtitleText) + '</p></div></div>' +
        '<p class="no-snapshot" style="margin-top:20px">This save was recorded before version snapshots were turned on, so there is no saved dashboard to show for it \u2014 only the save time.</p></div>';
    } else {
      var sections = buildSnapshotSectionsHtml(entry);
      bodyInner = '<div class="wrap"><div class="masthead"><div><h1>' + escAttr(titleText) + '</h1><p class="sub">' + escAttr(subtitleText) + '</p></div>' +
        '<div class="meta">Dabaran &middot; Outbound Lead Gen<br><span class="n">' + entry.campaigns.length + '</span> campaigns &middot; Save #' + (index + 1) + '<br>Saved ' + formatWhen(entry.savedAt) + '</div></div>' +
        sections.kpiHtml + sections.panelsHtml + sections.tableHtml + '</div>';
    }
    return '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">' +
      '<meta name="viewport" content="width=device-width, initial-scale=1">' +
      '<title>Save #' + (index + 1) + ' \u2014 ' + escAttr(titleText) + '</title>' +
      fontLinks + css + '</head><body>' + bodyInner + '</body></html>';
  }

  function openHistoryStandaloneTab(index) {
    try {
      var history = Array.isArray(STATE.history) ? STATE.history : [];
      var entry = history[index];
      if (!entry) return;
      var win = window.open("", "_blank");
      if (!win || !win.document) {
        try { alert("Naya tab open nahi ho saka is view mein \u2014 popups allow karke dobara try karein."); } catch (e2) {}
        return;
      }
      var docHtml = buildHistoryStandaloneDoc(entry, index);
      win.document.open();
      win.document.write(docHtml);
      win.document.close();
    } catch (err) {
      try { alert("Naya tab open nahi ho saka is view mein."); } catch (e2) {}
    }
  }

  function openStandaloneDocInTab(docHtml) {
    try {
      var win = window.open("", "_blank");
      if (!win || !win.document) return false;
      win.document.open();
      win.document.write(docHtml);
      win.document.close();
      return true;
    } catch (err) {
      return false;
    }
  }

  // Called right after a successful "Save changes" — automatically opens
  // the same standalone snapshot doc used for Save-history entries in a
  // new browser tab. No file is downloaded to disk: the snapshot itself
  // already lives inside this saved state (the Save history list below),
  // so it can always be reopened later without needing a separate file.
  function openSaveInNewTab(entry, index) {
    var docHtml = buildHistoryStandaloneDoc(entry, index);
    openStandaloneDocInTab(docHtml);
  }

  var githubStatusEl = document.getElementById("githubStatus");
  function setGithubStatus(kind, text) {
    if (!githubStatusEl) return;
    githubStatusEl.hidden = false;
    githubStatusEl.className = "hint" + (kind ? " " + kind : "");
    githubStatusEl.textContent = text;
  }

  // Called right after a successful "Save changes" -- pushes the same
  // standalone snapshot doc used for Save-history entries to a GitHub
  // repo, as a real committed file. This never happens directly from the
  // browser: the GitHub token that can write to your repo must stay on a
  // small server you control (a Cloudflare Worker -- see worker/SETUP.md),
  // never inside this page's own code, since anyone who opens this page
  // can read its JavaScript. Until GITHUB_SAVE_CONFIG is filled in and
  // enabled, this quietly does nothing -- Save changes still works exactly
  // as before.
  function pushSnapshotToGitHub(entry, index) {
    if (!GITHUB_SAVE_CONFIG.enabled || !GITHUB_SAVE_CONFIG.workerUrl) return;
    try {
      var docHtml = buildHistoryStandaloneDoc(entry, index);
      var stampSource = (entry && entry.savedAt) ? entry.savedAt : new Date().toISOString();
      var stamp = stampSource.replace(/[:.]/g, "-");
      var path = "saves/dabaran-report-save-" + (index + 1) + "-" + stamp + ".html";
      setGithubStatus("", "Pushing to GitHub…");
      fetch(GITHUB_SAVE_CONFIG.workerUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Dashboard-Key": GITHUB_SAVE_CONFIG.dashboardKey
        },
        body: JSON.stringify({
          path: path,
          content: docHtml,
          message: "Save #" + (index + 1) + " — " + stampSource
        })
      }).then(function (res) {
        if (!res.ok) { throw new Error("HTTP " + res.status); }
        return res.json();
      }).then(function () {
        setGithubStatus("ok", "Pushed to GitHub ✓");
      }).catch(function () {
        setGithubStatus("error", "GitHub push failed — check worker setup");
      });
    } catch (err) {
      setGithubStatus("error", "GitHub push failed — check worker setup");
    }
  }

  var historyModalOverlay = document.getElementById("historyModalOverlay");
  var historyModalRestoreBtn = document.getElementById("historyModalRestore");
  var historyModalDeleteBtn = document.getElementById("historyModalDelete");
  var historyModalOpenTabBtn = document.getElementById("historyModalOpenTab");
  var activeHistoryEntry = null;
  var activeHistoryIndex = null;

  function deleteHistoryEntry(index) {
    var history = Array.isArray(STATE.history) ? STATE.history : [];
    if (index < 0 || index >= history.length) return;
    history.splice(index, 1);
    renderSaveHistory();
    markDirty();
  }

  function openHistoryModal(index) {
    var history = Array.isArray(STATE.history) ? STATE.history : [];
    var entry = history[index];
    if (!entry) return;
    activeHistoryEntry = entry;
    activeHistoryIndex = index;
    document.getElementById("historyModalTitle").textContent = "Save #" + (index + 1);
    document.getElementById("historyModalWhen").textContent = "Saved " + formatWhen(entry.savedAt);
    renderHistorySnapshot(entry);
    historyModalRestoreBtn.style.display = Array.isArray(entry.campaigns) && !isReportMode ? "" : "none";
    historyModalDeleteBtn.style.display = isReportMode ? "none" : "";
    historyModalOverlay.hidden = false;
  }

  function closeHistoryModal() {
    historyModalOverlay.hidden = true;
    activeHistoryEntry = null;
    activeHistoryIndex = null;
  }

  document.getElementById("saveHistoryList").addEventListener("click", function (e) {
    var delBtn = e.target.closest(".history-del-btn");
    if (delBtn) {
      deleteHistoryEntry(Number(delBtn.dataset.historyIndex));
      return;
    }
    var openBtn = e.target.closest(".history-open-btn");
    if (openBtn) {
      openHistoryStandaloneTab(Number(openBtn.dataset.historyIndex));
      return;
    }
    var li = e.target.closest("li[data-history-index]");
    if (!li) return;
    openHistoryModal(Number(li.dataset.historyIndex));
  });
  document.getElementById("saveHistoryList").addEventListener("keydown", function (e) {
    if (e.key !== "Enter" && e.key !== " ") return;
    if (e.target.closest(".history-del-btn") || e.target.closest(".history-open-btn")) return;
    var li = e.target.closest("li[data-history-index]");
    if (!li) return;
    e.preventDefault();
    openHistoryModal(Number(li.dataset.historyIndex));
  });
  document.getElementById("historyModalClose").addEventListener("click", function () { closeHistoryModal(); });
  historyModalOpenTabBtn.addEventListener("click", function () {
    if (activeHistoryIndex === null) return;
    openHistoryStandaloneTab(activeHistoryIndex);
  });
  historyModalDeleteBtn.addEventListener("click", function () {
    if (activeHistoryIndex === null) return;
    deleteHistoryEntry(activeHistoryIndex);
    persistState({ campaigns: campaigns, overrides: STATE.overrides, title: STATE.title, subtitle: STATE.subtitle, history: STATE.history, lastSaved: STATE.lastSaved });
    closeHistoryModal();
  });
  historyModalOverlay.addEventListener("click", function (e) {
    if (e.target === historyModalOverlay) closeHistoryModal();
  });
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && !historyModalOverlay.hidden) closeHistoryModal();
  });
  historyModalRestoreBtn.addEventListener("click", function () {
    if (!activeHistoryEntry || !Array.isArray(activeHistoryEntry.campaigns)) return;
    campaigns.length = 0;
    JSON.parse(JSON.stringify(activeHistoryEntry.campaigns)).forEach(function (c) { campaigns.push(c); });
    STATE.overrides = JSON.parse(JSON.stringify(activeHistoryEntry.overrides || {}));
    if (typeof activeHistoryEntry.title === "string") { STATE.title = activeHistoryEntry.title; titleEl.textContent = STATE.title; }
    if (typeof activeHistoryEntry.subtitle === "string") { STATE.subtitle = activeHistoryEntry.subtitle; subtitleEl.textContent = STATE.subtitle; }
    renderTable();
    renderDerived();
    markDirty();
    persistState({ campaigns: campaigns, overrides: STATE.overrides, title: STATE.title, subtitle: STATE.subtitle, history: STATE.history, lastSaved: STATE.lastSaved });
    closeHistoryModal();
  });
  // ---------- Derived sections (KPI / chart / funnel / masthead meta) ----------
  function renderDerived() {
    recalcRates();
    var t = totals();
    var meetings = campaigns.reduce(function (a, c) { return a + (c.meetings || 0); }, 0);

    document.getElementById("campaignCount").textContent = campaigns.length;
    var complete = campaigns.filter(function (c) { return c.status === "Complete"; }).length;
    document.getElementById("statusSummary").textContent = complete + " complete, " + (campaigns.length - complete) + " in progress";
    document.getElementById("lastSavedLine").textContent = STATE.lastSaved
      ? "Last saved " + new Date(STATE.lastSaved).toLocaleString("en-US", { month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit" })
      : "Not yet saved";

    // KPI tiles — each has a computed value but can be overridden by typing directly into it
    var kpis = [
      { label: "Contacts sent", overrideKey: "sent", kind: "count", raw: t.sent, unit: "across " + campaigns.length + " sends", key: "sent" },
      { label: "Open rate", overrideKey: "openRate", kind: "pct1", raw: t.openRate, unit: fmt(t.opens) + " opened", key: "openRate" },
      { label: "Reply rate", overrideKey: "replyRate", kind: "pct2", raw: t.replyRate, unit: fmt(t.replies) + " replies", key: "replyRate" },
      { label: "Interested replies", overrideKey: "interested", kind: "count", raw: t.interested, unit: "of " + fmt(t.replies) + " replies", key: "interested" },
      { label: "Opportunities created", overrideKey: "opportunities", kind: "count", raw: t.opportunities, unit: t.opportunities + " campaign" + (t.opportunities === 1 ? "" : "s") + " converted", key: "opportunities" },
      { label: "Meetings booked", overrideKey: "meetings", kind: "count", raw: meetings, unit: meetings > 0 ? "booked to date" : "none yet this cycle", flatWhenZero: true, key: "meetings" }
    ];
    var kpiGrid = document.getElementById("kpiGrid");
    kpiGrid.innerHTML = "";
    kpis.forEach(function (k) {
      var tile = document.createElement("div");
      tile.className = "kpi";
      var sparkSvg = "";
      if (k.key) {
        var vals = campaigns.map(function (c) { return c[k.key]; });
        var max = Math.max.apply(null, vals) || 1;
        var w = 100 / vals.length;
        var bars = vals.map(function (v, i) {
          var h = Math.max((v / max) * 22, v > 0 ? 2 : 1);
          var cls = v > 0 ? "" : "zero";
          return '<rect class="' + cls + '" x="' + (i * w + w * 0.15).toFixed(2) + '%" y="' + (26 - h).toFixed(1) +
                 '" width="' + (w * 0.7).toFixed(2) + '%" height="' + h.toFixed(1) + '" rx="1.5"></rect>';
        }).join("");
        sparkSvg = '<svg class="spark" viewBox="0 0 100 26" preserveAspectRatio="none">' + bars + '</svg>';
      }
      var hasOverride = STATE.overrides[k.overrideKey] !== undefined && STATE.overrides[k.overrideKey] !== null;
      var displayNum = hasOverride ? STATE.overrides[k.overrideKey] : k.raw;
      var flat = k.flatWhenZero && !hasOverride && displayNum === 0;
      var valueSpan = isReportMode
        ? '<span class="value" style="cursor:default">' + formatByKind(k.kind, displayNum) + '</span>'
        : '<span class="value" contenteditable="true" spellcheck="false" data-override-key="' + k.overrideKey + '" data-kind="' + k.kind + '" data-raw="' + displayNum + '" title="Click to type in a number directly">' + formatByKind(k.kind, displayNum) + '</span>';
      tile.innerHTML =
        '<div class="label">' + k.label + '</div>' +
        '<div class="value-row">' +
          valueSpan +
          (hasOverride && !isReportMode ? '<button type="button" class="reset-btn" data-override-key="' + k.overrideKey + '" title="Recalculate from campaign data">&#8635;</button>' : '') +
        '</div>' +
        '<div class="caption' + (flat ? ' flat' : '') + '">' + (hasOverride ? (isReportMode ? "reported figure" : "set manually") : k.unit) + '</div>' +
        sparkSvg;
      kpiGrid.appendChild(tile);
    });

    // Bar chart
    var barChart = document.getElementById("barChart");
    barChart.innerHTML = "";
    var sorted = campaigns.slice().sort(function (a, b) { return b.openRate - a.openRate; });
    var maxRate = Math.max.apply(null, sorted.map(function (c) { return c.openRate; })) || 1;
    sorted.forEach(function (c) {
      var row = document.createElement("div");
      row.className = "bar-row";
      var widthPct = (c.openRate / maxRate) * 100;
      row.innerHTML =
        '<div class="name" title="' + (c.name || "").replace(/"/g, "&quot;") + '">' + (c.name || "Untitled") + '</div>' +
        '<div class="bar-track"><div class="bar-fill" tabindex="0" style="width:' + widthPct.toFixed(1) + '%"></div></div>' +
        '<div class="pct">' + pct(c.openRate, 1) + '</div>';
      var fill = row.querySelector(".bar-fill");
      var html = '<b>' + c.name + '</b><br>' + fmt(c.opens) + ' opened of ' + fmt(c.sent) + ' sent<br>' + pct(c.openRate, 2) + ' open rate';
      fill.addEventListener("mouseenter", function (e) { showTip(e, html); });
      fill.addEventListener("mousemove", function (e) { showTip(e, html); });
      fill.addEventListener("mouseleave", hideTip);
      barChart.appendChild(row);
    });

    // Funnel
    var stages = [
      { stage: "Sent", value: t.sent, color: "var(--seq-1)" },
      { stage: "Opened", value: t.opens, color: "var(--seq-2)" },
      { stage: "Replied", value: t.replies, color: "var(--seq-3)" },
      { stage: "Interested", value: t.interested, color: "var(--seq-4)" },
      { stage: "Opportunity", value: t.opportunities, color: "var(--seq-5)" }
    ];
    var funnel = document.getElementById("funnel");
    funnel.innerHTML = "";
    var sqrtMax = Math.sqrt(stages[0].value) || 1;
    stages.forEach(function (s, i) {
      var row = document.createElement("div");
      row.className = "funnel-row";
      var w = Math.max((Math.sqrt(s.value) / sqrtMax) * 100, 3);
      var pctOfSent = t.sent > 0 ? (s.value / t.sent * 100) : 0;
      var pctLabel = pctOfSent >= 1 ? pctOfSent.toFixed(1) + "%" : pctOfSent.toFixed(3) + "%";
      row.innerHTML =
        '<div class="stage">' + s.stage + '</div>' +
        '<div class="funnel-track"><div class="funnel-fill" tabindex="0" style="width:' + w.toFixed(1) + '%;background:' + s.color + '"></div></div>' +
        '<div class="count">' + fmt(s.value) + '</div>';
      funnel.appendChild(row);
      if (i > 0) {
        var prev = stages[i - 1];
        var drop = document.createElement("div");
        drop.className = "funnel-drop";
        var convFromPrev = prev.value > 0 ? (s.value / prev.value * 100) : 0;
        drop.textContent = prev.stage === "Sent"
          ? pctLabel + " of total sent"
          : convFromPrev.toFixed(convFromPrev < 1 ? 2 : 1) + "% of " + prev.stage.toLowerCase() + " · " + pctLabel + " of total sent";
        funnel.appendChild(drop);
      }
      var fill = row.querySelector(".funnel-fill");
      var html = '<b>' + fmt(s.value) + '</b> ' + s.stage.toLowerCase() + '<br>' + pctLabel + ' of total sent';
      fill.addEventListener("mouseenter", function (e) { showTip(e, html); });
      fill.addEventListener("mousemove", function (e) { showTip(e, html); });
      fill.addEventListener("mouseleave", hideTip);
    });
  }

  // ---------- Table (rebuilt only on add/remove, not on every keystroke) ----------
  function renderTable() {
    recalcRates();
    var tbody = document.getElementById("campTbody");
    tbody.innerHTML = "";

    if (isReportMode) {
      campaigns.forEach(function (c) {
        var tr = document.createElement("tr");
        tr.innerHTML =
          '<td><span class="camp-name" style="font-weight:600">' + escAttr(c.name) + '</span><span class="segment-input" style="display:block">' + escAttr(c.segment) + '</span></td>' +
          '<td>' + escAttr(c.window) + '</td>' +
          '<td class="num mono">' + fmt(c.sent) + '</td>' +
          '<td class="num mono">' + fmt(c.opens) + ' <span style="color:var(--ink-muted)">(' + pct(c.openRate, 1) + ')</span></td>' +
          '<td class="num mono">' + fmt(c.replies) + ' <span style="color:var(--ink-muted)">(' + pct(c.replyRate, 2) + ')</span></td>' +
          '<td class="num mono">' + fmt(c.dnc) + '</td>' +
          '<td class="num mono">' + fmt(c.interested) + '</td>' +
          '<td class="num mono">' + fmt(c.opportunities) + '</td>' +
          '<td class="num mono">' + fmt(c.meetings || 0) + '</td>' +
          '<td><span class="pill ' + pillClassFor(c.status) + '"><span class="dot"></span>' + escAttr(c.status) + '</span></td>' +
          '<td class="mono">' + escAttr(c.completed) + '</td>' +
          '<td></td>';
        tbody.appendChild(tr);
      });
      return;
    }

    campaigns.forEach(function (c, i) {
      var tr = document.createElement("tr");
      tr.dataset.index = i;
      tr.innerHTML =
        '<td>' +
          '<input class="cell-input name-input" data-field="name" value="' + escAttr(c.name) + '" title="' + escAttr(c.name) + '" placeholder="Campaign name">' +
          '<input class="cell-input segment-input" data-field="segment" value="' + escAttr(c.segment) + '" title="' + escAttr(c.segment) + '" placeholder="Segment / list">' +
        '</td>' +
        '<td><input class="cell-input" data-field="window" value="' + escAttr(c.window) + '" placeholder="Send window"></td>' +
        '<td class="num"><input class="cell-input" type="number" min="0" step="1" data-field="sent" value="' + c.sent + '"></td>' +
        '<td class="num"><input class="cell-input" type="number" min="0" step="1" data-field="opens" value="' + c.opens + '"></td>' +
        '<td class="num"><input class="cell-input" type="number" min="0" step="1" data-field="replies" value="' + c.replies + '"></td>' +
        '<td class="num"><input class="cell-input" type="number" min="0" step="1" data-field="dnc" value="' + c.dnc + '"></td>' +
        '<td class="num"><input class="cell-input" type="number" min="0" step="1" data-field="interested" value="' + c.interested + '"></td>' +
        '<td class="num"><input class="cell-input" type="number" min="0" step="1" data-field="opportunities" value="' + c.opportunities + '"></td>' +
        '<td class="num"><input class="cell-input" type="number" min="0" step="1" data-field="meetings" value="' + (c.meetings || 0) + '"></td>' +
        '<td>' +
          '<span class="status-cell">' +
            '<span class="pill ' + pillClassFor(c.status) + '"><span class="dot"></span>' + c.status + '</span>' +
            '<select class="cell-input" data-field="status">' +
              ["Complete", "Continue for Sending", "Paused", "Not started"].map(function (opt) {
                return '<option' + (opt === c.status ? ' selected' : '') + '>' + opt + '</option>';
              }).join("") +
            '</select>' +
          '</span>' +
        '</td>' +
        '<td><input class="cell-input" data-field="completed" value="' + escAttr(c.completed) + '" placeholder="—"></td>' +
        '<td><button class="del-btn" type="button" title="Remove campaign">&times;</button></td>';
      tr.querySelector(".del-btn").addEventListener("click", function () {
        campaigns.splice(i, 1);
        renderTable();
        renderDerived();
        markDirty();
      });
      tbody.appendChild(tr);
    });
  }

  function escAttr(s) { return (s || "").replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;"); }

  // Delegated input handling — updates state without rebuilding the table (keeps focus)
  document.getElementById("campTbody").addEventListener("input", function (e) {
    var field = e.target.dataset.field;
    if (!field) return;
    var tr = e.target.closest("tr");
    var idx = Number(tr.dataset.index);
    var c = campaigns[idx];
    if (["sent", "opens", "replies", "dnc", "interested", "opportunities", "meetings"].indexOf(field) !== -1) {
      c[field] = num(e.target.value);
    } else {
      c[field] = e.target.value;
      e.target.title = e.target.value;
    }
    if (field === "status") {
      var pill = tr.querySelector(".pill");
      pill.className = "pill " + pillClassFor(c.status);
      pill.innerHTML = '<span class="dot"></span>' + c.status;
    }
    renderDerived();
    markDirty();
  });

  document.getElementById("addBtn").addEventListener("click", function () {
    campaigns.push({
      name: "New campaign", segment: "", window: "",
      sent: 0, opens: 0, replies: 0, dnc: 0, interested: 0, opportunities: 0, meetings: 0,
      status: "Not started", completed: "—"
    });
    renderTable();
    renderDerived();
    markDirty();
    var rows = document.querySelectorAll("#campTbody tr");
    var last = rows[rows.length - 1];
    if (last) last.querySelector('[data-field="name"]').focus();
  });

  // ---------- KPI tile overrides (click a headline number to type your own) ----------
  var kpiGridEl = document.getElementById("kpiGrid");

  function selectAllText(el) {
    var range = document.createRange();
    range.selectNodeContents(el);
    var sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
  }

  // focus/blur don't bubble — use the capture phase
  kpiGridEl.addEventListener("focus", function (e) {
    if (!e.target.classList || !e.target.classList.contains("value")) return;
    e.target.textContent = e.target.dataset.raw;
    selectAllText(e.target);
  }, true);

  kpiGridEl.addEventListener("blur", function (e) {
    if (!e.target.classList || !e.target.classList.contains("value")) return;
    if (e.target.dataset.canceled === "1") {
      delete e.target.dataset.canceled;
      renderDerived();
      return;
    }
    var key = e.target.dataset.overrideKey;
    var kind = e.target.dataset.kind;
    var n = parseByKind(kind, e.target.textContent);
    STATE.overrides[key] = n;
    markDirty();
    renderDerived();
  }, true);

  kpiGridEl.addEventListener("keydown", function (e) {
    if (!e.target.classList || !e.target.classList.contains("value")) return;
    if (e.key === "Enter") { e.preventDefault(); e.target.blur(); }
    if (e.key === "Escape") { e.preventDefault(); e.target.dataset.canceled = "1"; e.target.blur(); }
  });

  kpiGridEl.addEventListener("click", function (e) {
    if (!e.target.classList || !e.target.classList.contains("reset-btn")) return;
    var key = e.target.dataset.overrideKey;
    delete STATE.overrides[key];
    markDirty();
    renderDerived();
  });

  // ---------- Title & subtitle (editable heading) ----------
  var titleEl = document.getElementById("reportTitle");
  var subtitleEl = document.getElementById("reportSubtitle");
  if (typeof STATE.title === "string" && STATE.title) { titleEl.textContent = STATE.title; }
  if (typeof STATE.subtitle === "string") { subtitleEl.textContent = STATE.subtitle; }
  [titleEl, subtitleEl].forEach(function (el) {
    el.addEventListener("blur", function () {
      var text = el.textContent.replace(/\s+/g, " ").trim();
      if (el === titleEl) { STATE.title = text || "Untitled report"; el.textContent = STATE.title; }
      else { STATE.subtitle = text; el.textContent = STATE.subtitle; }
      markDirty();
    });
    el.addEventListener("keydown", function (e) {
      if (e.key === "Enter") { e.preventDefault(); el.blur(); }
    });
  });

  // ---------- Save / publish ----------
  var saveStatusEl = document.getElementById("saveStatus");
  var saveStatusText = document.getElementById("saveStatusText");
  var saveBtn = document.getElementById("saveBtn");

  function markDirty() {
    dirty = true;
    saveStatusEl.className = "save-status dirty";
    saveStatusText.textContent = "Unsaved changes";
  }
  function markSaved() {
    dirty = false;
    saveStatusEl.className = "save-status saved";
    saveStatusText.textContent = "All changes saved";
  }
  function markError(msg) {
    saveStatusEl.className = "save-status error";
    saveStatusText.textContent = msg;
  }

  saveBtn.addEventListener("click", function () {
    saveChanges();
  });

  function persistState(newState) {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(newState));
      return true;
    } catch (e) {
      return false;
    }
  }

  function saveChanges() {
    saveBtn.disabled = true;
    saveStatusEl.className = "save-status";
    saveStatusText.textContent = "Saving…";
    var nowIso = new Date().toISOString();
    var snapshot = {
      savedAt: nowIso,
      campaigns: JSON.parse(JSON.stringify(campaigns)),
      overrides: JSON.parse(JSON.stringify(STATE.overrides)),
      title: STATE.title,
      subtitle: STATE.subtitle
    };
    var newHistory = (Array.isArray(STATE.history) ? STATE.history : []).concat([snapshot]);
    if (newHistory.length > 150) { newHistory = newHistory.slice(newHistory.length - 150); }
    var newState = { campaigns: campaigns, overrides: STATE.overrides, title: STATE.title, subtitle: STATE.subtitle, history: newHistory, lastSaved: nowIso };
    var ok = persistState(newState);
    saveBtn.disabled = false;
    if (!ok) {
      markError("Couldn't save to this browser's local storage — try again, or check it isn't full/blocked.");
      return;
    }
    STATE = newState;
    renderSaveHistory();
    markSaved();
    openSaveInNewTab(snapshot, newHistory.length - 1);
    pushSnapshotToGitHub(snapshot, newHistory.length - 1);
  }

  // ---------- Init ----------
  if (isReportMode) {
    document.getElementById("saveBar").style.display = "none";
    document.getElementById("tableFoot").style.display = "none";
    document.getElementById("tableEyebrow").textContent = "Campaign detail";
    document.getElementById("reportTitle").removeAttribute("contenteditable");
    document.getElementById("reportTitle").removeAttribute("title");
    document.getElementById("reportSubtitle").removeAttribute("contenteditable");
    document.getElementById("reportSubtitle").removeAttribute("title");
    document.title = "Dabaran Cold Outreach Report — locked";
  }

  renderTable();
  renderDerived();
  renderSaveHistory();
  if (STATE.lastSaved) { markSaved(); } else { saveStatusText.textContent = "No edits yet"; }
})();