# GitHub par automatic save — setup guide

Ye guide bataega ke "Save changes" click karne par dashboard ka snapshot automatically aapke GitHub repo mein ek file ke taur par kaise save ho.

**Zaroori baat pehle:** Dashboard khud browser mein chalta hai, aur browser mein chalne wala koi bhi code "public" hota hai — jo bhi page open karega wo us code ko dekh sakta hai. Is wajah se GitHub token (jo repo mein likhne ki permission deta hai) seedha dashboard ke andar nahi rakha ja sakta, warna koi bhi use chura kar aapke repo mein kuch bhi likh sakta hai. Isliye ek chhota sa "Worker" (ek mini server, Cloudflare par free) beech mein rakha jata hai — token sirf wahan store hota hai, dashboard sirf us Worker ko request bhejta hai, aur Worker hi GitHub se baat karta hai.

Total 5 steps hain. Har step ek baar karna hai.

## Step 1 — GitHub repo banayein

1. https://github.com/new par jayein (GitHub account se login hona zaroori hai)
2. Repo ka naam dein (jaise `dabaran-dashboard-saves`)
3. Private ya Public — jo chahein (Private zyada mehfooz hai agar aap nahi chahte koi aur saves dekhe)
4. "Create repository" click karein
5. Repo ka naam aur apna GitHub username note kar lein — agle steps mein chahiye honge (jaise `nuhaid123/dabaran-dashboard-saves`)

## Step 2 — GitHub token banayein

1. https://github.com/settings/personal-access-tokens/new par jayein
2. "Token name" mein kuch bhi likh dein (jaise `dabaran-dashboard-worker`)
3. "Expiration" mein jitna lamba chahein rakh sakte hain (jaise 1 year — token expire hone par naya banana padega)
4. "Repository access" mein **"Only select repositories"** choose karein, aur Step 1 wala repo select karein — **poore account ki permission mat dein**
5. "Permissions" ke andar "Repository permissions" mein **Contents** ko **"Read and write"** set karein — baaki sab default/"No access" rehne dein
6. "Generate token" click karein
7. Jo token screen par ek baar dikhega (`github_pat_...` se shuru hoga) usay turant copy kar ke kahin safe jagah save kar lein — dobara nahi dikhega

## Step 3 — Cloudflare Worker banayein

1. https://dash.cloudflare.com/ par free account banayein (agar nahi hai)
2. Left menu mein "Workers & Pages" par jayein → "Create" → "Create Worker"
3. Koi bhi naam dein (jaise `dabaran-save-worker`) → "Deploy" click karein (abhi ke liye default code ke saath)
4. Deploy hone ke baad "Edit code" (ya "Quick edit") button dabayein
5. Us editor mein jo bhi default code hai use pura select kar ke delete kar dein, aur is folder ki `worker.js` file ka pura content wahan paste kar dein
6. "Save and deploy" / "Deploy" dabayein
7. Ab worker ka URL note kar lein — kuch aisa dikhega: `https://dabaran-save-worker.YOURSUBDOMAIN.workers.dev`

## Step 4 — Worker mein secrets/settings set karein

Worker ke page par "Settings" → "Variables and Secrets" (ya "Environment Variables") mein jayein aur ye add karein:

| Naam | Type | Value |
|---|---|---|
| `GITHUB_TOKEN` | **Secret** | Step 2 wala token (`github_pat_...`) |
| `GITHUB_OWNER` | Plain text | Aapka GitHub username (jaise `nuhaid123`) |
| `GITHUB_REPO` | Plain text | Step 1 wala repo naam (jaise `dabaran-dashboard-saves`) |
| `GITHUB_BRANCH` | Plain text | `main` (agar aapke repo ki default branch kuch aur hai to wo likhein) |
| `DASHBOARD_SHARED_KEY` | **Secret** | Khud koi lamba random text bana lein (jaise `db-9f3a7k2m-secret`) — isay yaad rakhein, Step 5 mein dobara chahiye hoga |
| `ALLOWED_ORIGIN` | Plain text | Agar dashboard ko GitHub Pages par bhi host karenge, to uska URL (jaise `https://nuhaid123.github.io`); testing ke liye abhi `*` bhi likh sakte hain |

Save karne ke baad Worker khud-ba-khud redeploy ho jata hai.

## Step 5 — Dashboard ki `script.js` file update karein

`script.js` file ke bilkul shuru mein ye block milega:

```js
var GITHUB_SAVE_CONFIG = {
  enabled: false,
  workerUrl: "",
  dashboardKey: ""
};
```

Isay is tarah bharein (apni values ke saath):

```js
var GITHUB_SAVE_CONFIG = {
  enabled: true,
  workerUrl: "https://dabaran-save-worker.YOURSUBDOMAIN.workers.dev",
  dashboardKey: "db-9f3a7k2m-secret"
};
```

(`workerUrl` = Step 3 ka URL, `dashboardKey` = Step 4 mein banaya hua `DASHBOARD_SHARED_KEY`)

Save kar ke dashboard reload karein.

## Test kaise karein

1. Dashboard mein koi bhi cheez edit karein (jaise ek number)
2. "Save changes" click karein
3. Save button ke pass ek chhota sa status dikhega: "Pushing to GitHub…" phir "Pushed to GitHub ✓"
4. Apne GitHub repo mein jayein — ek naya `saves/` folder aur usme ek nayi `.html` file dikhni chahiye

Agar "GitHub push failed" dikhe, to ye check karein:
- Step 4 ki saari values sahi likhi hain (typo na ho)
- Token abhi expire nahi hua
- Token ko sirf Step 1 wale repo ki "Contents: Read and write" permission di gayi hai

## Ye kaam kaise karta hai (short version)

Dashboard → (POST request, sath mein `dashboardKey`) → Cloudflare Worker → (token ke sath) → GitHub API → file commit ho jati hai repo mein.

Token kabhi bhi dashboard ke andar nahi jata — sirf Worker ke settings mein rehta hai, jo koi bhi viewer dekh nahi sakta.
