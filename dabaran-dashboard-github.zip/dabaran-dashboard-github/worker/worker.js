/**
 * Dabaran dashboard -> GitHub auto-save worker.
 *
 * This runs on Cloudflare Workers, NOT in the browser. Its whole job is to
 * hold your GitHub token somewhere the dashboard's own (public) code can
 * never see it, and to write a file to your GitHub repo whenever the
 * dashboard asks it to.
 *
 * Deploy steps are in SETUP.md next to this file. Short version: paste this
 * file into a new Cloudflare Worker, then set these under
 * Worker Settings -> Variables and Secrets:
 *
 *   GITHUB_TOKEN          (secret)  fine-grained GitHub token, Contents:
 *                                   Read and write, scoped to ONE repo only
 *   GITHUB_OWNER          (plain)   your GitHub username or org
 *   GITHUB_REPO           (plain)   the repo name
 *   GITHUB_BRANCH         (plain)   usually "main" (optional, defaults to main)
 *   DASHBOARD_SHARED_KEY  (secret)  a random string you make up yourself --
 *                                   the dashboard must send this exact same
 *                                   string back, so random strangers who
 *                                   stumble on this Worker's URL can't use
 *                                   it to write into your repo
 *   ALLOWED_ORIGIN        (plain)   the exact URL your dashboard is served
 *                                   from (e.g. https://you.github.io), or
 *                                   "*" while you're still testing locally
 */

export default {
  async fetch(request, env) {
    const allowedOrigin = env.ALLOWED_ORIGIN || "*";
    const corsHeaders = {
      "Access-Control-Allow-Origin": allowedOrigin,
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, X-Dashboard-Key",
    };

    if (request.method === "OPTIONS") {
      return new Response(null, { headers: corsHeaders });
    }

    if (request.method !== "POST") {
      return json({ error: "method_not_allowed" }, 405, corsHeaders);
    }

    if (!env.DASHBOARD_SHARED_KEY) {
      return json({ error: "worker_not_configured", detail: "DASHBOARD_SHARED_KEY is not set" }, 500, corsHeaders);
    }
    const dashboardKey = request.headers.get("X-Dashboard-Key");
    if (dashboardKey !== env.DASHBOARD_SHARED_KEY) {
      return json({ error: "unauthorized" }, 401, corsHeaders);
    }

    let body;
    try {
      body = await request.json();
    } catch (err) {
      return json({ error: "bad_request", detail: "body is not valid JSON" }, 400, corsHeaders);
    }

    const filePath = body && body.path;
    const content = body && body.content;
    const message = (body && body.message) || ("Save " + filePath);

    if (typeof filePath !== "string" || !filePath || filePath.indexOf("..") !== -1) {
      return json({ error: "bad_request", detail: "missing or invalid 'path'" }, 400, corsHeaders);
    }
    if (typeof content !== "string" || !content) {
      return json({ error: "bad_request", detail: "missing or invalid 'content'" }, 400, corsHeaders);
    }

    const owner = env.GITHUB_OWNER;
    const repo = env.GITHUB_REPO;
    const branch = env.GITHUB_BRANCH || "main";
    const token = env.GITHUB_TOKEN;

    if (!owner || !repo || !token) {
      return json({ error: "worker_not_configured", detail: "GITHUB_OWNER, GITHUB_REPO or GITHUB_TOKEN is not set" }, 500, corsHeaders);
    }

    const apiUrl = "https://api.github.com/repos/" + owner + "/" + repo + "/contents/" + encodeGitHubPath(filePath);
    const base64Content = utf8ToBase64(content);
    const ghHeaders = {
      Authorization: "Bearer " + token,
      "User-Agent": "dabaran-dashboard-worker",
      Accept: "application/vnd.github+json",
    };

    // GitHub's Contents API needs the file's current `sha` to UPDATE it;
    // omit it to CREATE a new file. Look the file up first (a 404 here just
    // means it doesn't exist yet, which is fine).
    let sha;
    try {
      const existing = await fetch(apiUrl + "?ref=" + encodeURIComponent(branch), { headers: ghHeaders });
      if (existing.status === 200) {
        const existingJson = await existing.json();
        sha = existingJson.sha;
      } else if (existing.status !== 404) {
        const errJson = await safeJson(existing);
        return json({ error: "github_error", stage: "lookup", status: existing.status, detail: errJson }, 502, corsHeaders);
      }
    } catch (err) {
      return json({ error: "upstream_error", stage: "lookup", detail: String(err) }, 502, corsHeaders);
    }

    let putRes;
    try {
      putRes = await fetch(apiUrl, {
        method: "PUT",
        headers: Object.assign({ "Content-Type": "application/json" }, ghHeaders),
        body: JSON.stringify(
          Object.assign(
            { message: message, content: base64Content, branch: branch },
            sha ? { sha: sha } : {}
          )
        ),
      });
    } catch (err) {
      return json({ error: "upstream_error", stage: "write", detail: String(err) }, 502, corsHeaders);
    }

    const putJson = await safeJson(putRes);
    if (!putRes.ok) {
      return json({ error: "github_error", stage: "write", status: putRes.status, detail: putJson }, 502, corsHeaders);
    }

    return json(
      { ok: true, path: filePath, htmlUrl: putJson && putJson.content && putJson.content.html_url },
      200,
      corsHeaders
    );
  },
};

function json(obj, status, extraHeaders) {
  return new Response(JSON.stringify(obj), {
    status: status,
    headers: Object.assign({ "Content-Type": "application/json" }, extraHeaders || {}),
  });
}

async function safeJson(res) {
  try {
    return await res.json();
  } catch (err) {
    return null;
  }
}

function encodeGitHubPath(p) {
  // Encode each path segment separately so "/" stays a separator.
  return p.split("/").map(encodeURIComponent).join("/");
}

function utf8ToBase64(str) {
  const bytes = new TextEncoder().encode(str);
  let binary = "";
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}
